Cviceni 04
----------

This example draws animated cube using WebGL. Texture is mapped on the object using UV mapping.

**Note:** following steps are optional.

To install [node.js](https://nodejs.org/) [live web server](https://github.com/tapio/live-server) type following commands:

```bash
npm install live-server
```

To start live server type following command:

```bash
node live-server.js
```

This example require [glMatrix](http://glmatrix.net/) library. You can install
it using e.g.: `npm`:

```bash
npm install gl-matrix@2.2.0
```
